package com.example.project;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.project.R;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private static final int MAX_TRIES = 4;

    private final List<String> names = Arrays.asList("Ahmed", "Hamza", "Islamabad", "England", "Quetta");
    private int tries = MAX_TRIES;
    private String word;
    private StringBuilder star;

    private TextView wordTextView;
    private TextView triesTextView;
    private Button[] alphabetButtons;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        wordTextView = findViewById(R.id.wordTextView);
        triesTextView = findViewById(R.id.triesTextView);


        alphabetButtons = new Button[26];
        GridLayout alphabetLayout = findViewById(R.id.alphabetLayout);
        int columnCount = 4; // Number of columns for the grid layout

        for (int i = 0; i < 26; i++) {
            Button button = new Button(this);
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = GridLayout.LayoutParams.WRAP_CONTENT;
            params.height = GridLayout.LayoutParams.WRAP_CONTENT;
            params.columnSpec = GridLayout.spec(i % columnCount);
            params.rowSpec = GridLayout.spec(i / columnCount);
            button.setLayoutParams(params);

            button.setTextColor(Color.WHITE);
            button.setTextSize(26);
            button.setGravity(Gravity.CENTER);
            button.setOnClickListener(v -> {
                Button clickedButton = (Button) v;
                clickedButton.setEnabled(false);
                char letter = clickedButton.getText().charAt(0);
                handleLetterClick(letter);
            });

            char letter = (char) ('A' + i);
            button.setText(String.valueOf(letter));
            alphabetLayout.addView(button);
            alphabetButtons[i] = button;
        }

        startGame();
    }

    private void startGame() {
        Random random = new Random();
        int nameIndex = random.nextInt(names.size());
        word = names.get(nameIndex).toUpperCase();

        star = new StringBuilder(word.length());
        for (int i = 0; i < word.length(); i++) {
            star.append('*');
        }
        wordTextView.setText(star.toString());

        tries = MAX_TRIES;
        updateTriesTextView();
        resetAlphabetButtons();
    }

    private void handleLetterClick(char letter) {
        int matches = hang(letter, word, star);
        if (matches == 0) {
            Toast.makeText(this, "WRONG LETTER!!", Toast.LENGTH_SHORT).show();
            tries--;
            updateTriesTextView();

            if (tries == 3) {
                showHangmanPart("|||\n");
            } else if (tries == 2) {
                showHangmanPart("|||\n |\n |");
            } else if (tries == 1) {
                showHangmanPart("|||\n <|>\n  |");
            } else if (tries == 0) {
                showHangmanPart("|||\n <|>\n  |\n ? ?");
                endGame(false);
            }
        } else {
            Toast.makeText(this, "YOU FOUND THE LETTER!!", Toast.LENGTH_SHORT).show();
            wordTextView.setText(star.toString());

            if (word.equals(star.toString())) {
                endGame(true);
            }
        }
    }

    private void showHangmanPart(String part) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(part);
        builder.setCancelable(false);
        builder.setPositiveButton("OK", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @SuppressLint("SetTextI18n")
    private void updateTriesTextView() {
        triesTextView.setText("Tries left: " + tries);
    }

    private void endGame(boolean isWin) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        if (isWin) {
            builder.setMessage("YOU WON THE MATCH!!");
        } else {
            builder.setMessage("YOU LOSE!!\nThe word was: " + word);
        }
        builder.setCancelable(false);
        builder.setPositiveButton("Play Again", (dialog, which) -> startGame());
        builder.setNegativeButton("Exit", (dialog, which) -> finish());
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private int hang(char letter, String secret, StringBuilder guessword) {
        int matches = 0;
        int len = secret.length();

        for (int i = 0; i < len; i++) {
            if (letter == guessword.charAt(i)) {
                return 0;
            }
            if (letter == secret.charAt(i)) {
                guessword.setCharAt(i, letter);
                matches++;
            }
        }
        return matches;
    }

    private void resetAlphabetButtons() {
        for (Button button : alphabetButtons) {
            button.setEnabled(true);
        }
    }
}
